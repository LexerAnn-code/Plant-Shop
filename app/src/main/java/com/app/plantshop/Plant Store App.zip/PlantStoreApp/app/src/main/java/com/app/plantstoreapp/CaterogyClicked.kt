package com.app.plantstoreapp

import android.view.View

interface CaterogyClicked {
    fun caterogyClicked(category: Category)
}