package com.app.plantstoreapp

fun debugger(msg:Any?)=println("Message->>${msg.toString()}")