//package com.app.plantstoreapp
//
//object MockData2 {
//    fun categoryName2():MutableList<Category>{
//        val category= mutableListOf<Category>()
//        var details2= mutableListOf<CategoryList>()
//
//
//
//        for ( i in 0 until 1){
//           details2=CategoryList("Mango","12.50")
//            val cate=Category("Outdoor",details2)
//            category.add(cate)
//
//        }
//        return category
//
//    }
//}